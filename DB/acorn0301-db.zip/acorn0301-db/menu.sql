--------------------------------------------------------
--  파일이 생성됨 - 금요일-8월-02-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table MENU
--------------------------------------------------------

  CREATE TABLE "ACORN0301"."MENU" 
   (	"MENU_NUM" NUMBER, 
	"MENU_TYPE" VARCHAR2(500 BYTE), 
	"MENU_NAME_ENG" VARCHAR2(1000 BYTE), 
	"MENU_NAME_KOR" VARCHAR2(1000 BYTE), 
	"MENU_PRICE" NUMBER, 
	"MENU_IMG" VARCHAR2(2000 BYTE), 
	"MENU_DESC" VARCHAR2(2000 BYTE), 
	"MENU_TYPE_NUM" NUMBER
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
REM INSERTING into ACORN0301.MENU
SET DEFINE OFF;
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (58,'Breakfast','new','신메뉴',1212121,'Hydrangeas1564646706807.jpg',' dddd',0);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (1,'Breakfast','Pastry','패스트리',23000,'/1_Pastry/2.jpg','Lorem ipsum dolor sit amet, consectetur adipiscing elit',0);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (2,'Breakfast','Toast','토스트',23000,'/2_Toast/2.jpg','Suspendisse pretium, enim eget suscipit consectetur, urna mauris maximus turpis, vitae mollis ex leo a est',0);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (3,'Breakfast','Egg White omelet','흰자 오믈렛',23000,'/3_Egg_White omelet/4.jpg','Proin ultricies pharetra placerat',0);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (4,'Specialties','English muffin','잉글리시 머핀',20000,'/4_English_muffin/3.jpg','Praesent magna nibh, posuere non nisl eu, ultrices sollicitudin eros',1);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (5,'Specialties','Avocado Bacon bagel','크림치즈 연어 베이글',30000,'/5_Cream_cheese_salmon_bagel/2.jpg','Nulla imperdiet tellus vel ex vestibulum viverra',1);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (6,'Specialties','French toast','프렌치 토스트',20000,'/6_French_toast/2.jpg','Maecenas cursus felis ac vestibulum pulvinar',1);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (7,'Bakery','Croissant','크루아상',16000,'/7_Croissant/4.jpg','Donec sodales ac lorem id egestas',2);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (8,'Bakery','Danish Pastry','데니시 패스트리',16000,'/8_Danish_Pastry/3.png','Sed lacinia eget eros et vestibulum',2);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (9,'Bakery','Muffin','머핀',16000,'/9_Muffin/3.jpg','Vivamus ac semper arcu, vitae convallis urna',2);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (10,'Breakfast','Fruit yogurt','과일 플레인 요거트',15000,'/10_Fruit_yogurt/7.jpg','Maecenas tincidunt, magna at tristique tempor, libero urna feugiat risus, at convallis sem libero quis enim',0);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (11,'Breakfast','Banana granola','바나나 그래놀라',17000,'/11_Banana_granola/10.jpg','Quisque lobortis non purus nec aliquet',0);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (12,'Breakfast','Muesli Plain yogurt','뮤즐리 플레인 요거트',17000,'/12_Muesli_Plain yogurt/6.jpg','Nam posuere eu purus in sagittis',0);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (13,'Appetizers','Caesar salad','시저 샐러드',25000,'/19_Caesar_salad/1.gif','Praesent mattis sit amet lectus eget consectetur',3);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (14,'Appetizers','Cobb Salad','콥 샐러드',32000,'/20_Cobb_salad/4.jpg','Nam tempor nunc quis varius ultrices',3);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (15,'Appetizers','Truffle soup','트러플 양송이 수프',24000,'/21_Truffle_soup/5.jpg','Donec pellentesque mi vel orci scelerisque, sed elementum velit dignissim',3);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (16,'Appetizers','Seafood soup','해산물 수프',25000,'/22_Seafood_soup/1.jpg','Integer scelerisque lacus metus, vitae bibendum nibh porta nec',3);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (17,'Pastas','Creamy seafood spaghetti','크림 해산물 스파게티',36000,'/23_Creamy_seafood_spaghetti/1.jpg','Vestibulum rutrum et ex id condimentum',4);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (18,'Specialties','Crock Monsieur','크로크 무슈',31000,'/24_Crock_Monsieur/5.jpg','Cras tortor metus, porttitor et facilisis eu, molestie vitae diam',1);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (19,'Specialties','Club sandwich','클럽 샌드위치',33000,'/25_Club_sandwich/2.jpg','Integer elit nisi, consectetur at nulla et, cursus consectetur turpis',1);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (20,'Dessert','Cheese cake','크림 치즈 케이크',17000,'/26_Cheese_cake/2.jpg','Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos',5);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (21,'Dessert','Pecan pie','피칸 파이',19000,'/27_Pecan_pie/2.jpg','Praesent commodo vehicula ex pulvinar condimentum',5);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (22,'Dessert','Creme brulee','크림 브륄레',17000,'/28_Creme_brulee/1.jpg','Phasellus in risus sem',5);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (23,'Beverage','Americano','아메리카노',13000,'/13_Americano/3.jpg','Maecenas non sodales nunc. Praesent pretium cursus nibh, ac euismod neque vestibulum ac',6);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (24,'Beverage','Caffe Latte','카페라떼',13000,'/14_Caffe_Latte/3.jpg','Curabitur vestibulum eros eget turpis imperdiet, sed faucibus urna bibendum',6);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (25,'Beverage','Camomile','캐모마일',14000,'/15_Camomile/1.jpg','Cras laoreet dolor vitae ex lobortis, id faucibus nisl ullamcorper',6);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (26,'Beverage','Green tea','녹차',14000,'/16_Green_tea/3.jpg','Phasellus sed interdum leo',6);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (27,'Beverage','Orange juice','오렌지주스',17000,'/17_Orange_juice/1.jpg','Vestibulum eget laoreet quam',6);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (28,'Beverage','Apple juice','사과주스',17000,'/18_Apple_juice/1.jpg','Donec laoreet ullamcorper metus',6);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (29,'Drink','Dom Perignon Brut','돔페리뇽 브뤼',70000,'/29_Champagn/4.jpg','Aenean quis imperdiet magna, non porttitor quam',7);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (30,'Drink','Ferrari Brut','페라리 브뤼',50000,'/30_Wine/8.jpg','Vivamus ullamcorper mattis felis fermentum ullamcorper',7);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (31,'Drink','Draft beer','생맥주',10000,'/31_Beer/1.jpg','Nullam ut libero ut dolor pharetra sollicitudin eget maximus nibh. Morbi pulvinar, justo vitae iaculis tempus, odio felis semper leo, et hendrerit nunc erat eu nulla',7);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (32,'Specialties','Cream Cheese Salmon Bagel','크림 치즈 연어 베이글',30000,'/5_Cream_cheese_salmon_bagel/3.png','Proin et dui euismod, tempus quam quis, luctus leo',1);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (33,'Specialties','garlic bread','마늘 바게트',11000,'/8_Danish_Pastry/9.png','Vestibulum id porttitor felis, vitae scelerisque nunc',1);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (34,'Specialties','Waffle','와플',15000,'/8_Danish_Pastry/10.jpg','Cras luctus auctor sem, at luctus tortor fringilla eu',1);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (35,'Bakery','Earl Grey Pound Cake','얼그레이 파운드 케이크',18000,'/8_Danish_Pastry/11.jpg','Cras luctus auctor sem, at luctus tortor fringilla eu',2);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (36,'Appetizers','Asparagus Brie Puff Pastry','아스파라거스 패스트리',13000,'/19_Caesar_salad/5.jpg','nascetur ridiculus mus. Nunc placerat blandit felis',3);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (37,'Appetizers','Cranberry Brie','크렌베리 패스트리',12000,'/19_Caesar_salad/6.jpg','ac placerat augue. Sed maximus congue sem',3);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (38,'Pastas','Aglio e Olio','알리오 올리오',25000,'/23_Creamy_seafood_spaghetti/5.jpg','eget suscipit lacus vulputate vel',4);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (39,'Pastas','Rose Pasta','로제 파스타',23000,'/23_Creamy_seafood_spaghetti/6.jpg','Morbi et purus in sapien cursus consectetur maximus vel mi',4);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (40,'Pastas','Tomato Pasta','토마토 파스타',23000,'/23_Creamy_seafood_spaghetti/7.jpg','lobortis vitae urna sit amet, malesuada pharetra leo',4);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (41,'Pastas','Balsamic Salad Pasta','샐러드 파스타',26000,'/23_Creamy_seafood_spaghetti/8.jpg','porta ac leo et, luctus ultrices lectus',4);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (42,'Pastas','Pesto Pasta','페스토 파스타',25000,'/23_Creamy_seafood_spaghetti/9.jpg','Aenean fringilla sed risus at facilisis',4);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (43,'Dessert','Chocolate cake','초코 케이크',15000,'/26_Cheese_cake/4.jpg','Suspendisse enim tortor, lobortis ut odio eu',5);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (44,'Dessert','Chocolate IceCream','초코 아이스크림',12000,'/26_Cheese_cake/10.jpg','diam libero placerat mauris, nec tempor massa tortor non erat',5);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (45,'Dessert','GreenTea IceCream','녹차 아이스크림',12000,'/26_Cheese_cake/12.jpg','sit amet tempor lectus auctor vel',5);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (46,'Drink','White Wine','화이트 와인',50000,'/30_Wine/3.jpg','Pellentesque sit amet lorem non ipsum laoreet ullamcorper at id mi',7);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (47,'Drink','Chivas Regal','시바스 리갈',100000,'/30_Wine/11.jpg','Praesent et urna ut nunc hendrerit tincidunt in a dolor',7);
Insert into ACORN0301.MENU (MENU_NUM,MENU_TYPE,MENU_NAME_ENG,MENU_NAME_KOR,MENU_PRICE,MENU_IMG,MENU_DESC,MENU_TYPE_NUM) values (48,'Breakfast','Jack Daniel','잭 다니엘',220000,'/30_Wine/12.jpg','Nulla luctus feugiat dolor, ac ullamcorper urna sodales at',7);
--------------------------------------------------------
--  DDL for Index SYS_C005107
--------------------------------------------------------

  CREATE UNIQUE INDEX "ACORN0301"."SYS_C005107" ON "ACORN0301"."MENU" ("MENU_NUM") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  Constraints for Table MENU
--------------------------------------------------------

  ALTER TABLE "ACORN0301"."MENU" ADD PRIMARY KEY ("MENU_NUM")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
