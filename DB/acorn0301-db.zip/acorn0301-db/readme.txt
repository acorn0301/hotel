import 시 유의사항

1. create table 이하 acorn0301은 현재 사용하는 계정명으로 변경(대문자로)