--------------------------------------------------------
--  파일이 생성됨 - 금요일-8월-02-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table ADMINLOG
--------------------------------------------------------

  CREATE TABLE "ACORN0301"."ADMINLOG" 
   (	"LOG_NUM" NUMBER, 
	"MEMBER_NUM" NUMBER, 
	"LOG_TIME" DATE, 
	"LOG_TABLE" VARCHAR2(30 BYTE), 
	"LOG_ACT" VARCHAR2(500 BYTE), 
	"LOG_MEMO" VARCHAR2(500 BYTE), 
	"LOG_ATTR" VARCHAR2(200 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
REM INSERTING into ACORN0301.ADMINLOG
SET DEFINE OFF;
Insert into ACORN0301.ADMINLOG (LOG_NUM,MEMBER_NUM,LOG_TIME,LOG_TABLE,LOG_ACT,LOG_MEMO,LOG_ATTR) values (1,18,to_date('19/07/30 03:00:00','RR/MM/DD HH24:MI:SS'),'menu','insert',' ','all');
Insert into ACORN0301.ADMINLOG (LOG_NUM,MEMBER_NUM,LOG_TIME,LOG_TABLE,LOG_ACT,LOG_MEMO,LOG_ATTR) values (2,18,to_date('19/07/30 03:00:00','RR/MM/DD HH24:MI:SS'),'menu','delete',' ','all');
Insert into ACORN0301.ADMINLOG (LOG_NUM,MEMBER_NUM,LOG_TIME,LOG_TABLE,LOG_ACT,LOG_MEMO,LOG_ATTR) values (16,18,to_date('19/07/31 16:19:28','RR/MM/DD HH24:MI:SS'),'book','update',' ','head_count,breakfast_count');
Insert into ACORN0301.ADMINLOG (LOG_NUM,MEMBER_NUM,LOG_TIME,LOG_TABLE,LOG_ACT,LOG_MEMO,LOG_ATTR) values (4,18,to_date('19/07/30 03:00:00','RR/MM/DD HH24:MI:SS'),'menu','update',' ','menu_type_num,menu_name_kor');
Insert into ACORN0301.ADMINLOG (LOG_NUM,MEMBER_NUM,LOG_TIME,LOG_TABLE,LOG_ACT,LOG_MEMO,LOG_ATTR) values (5,18,to_date('19/07/30 03:00:00','RR/MM/DD HH24:MI:SS'),'menu','update',' dd','menu_type_num,menu_name_kor,menu_name_eng,menu_price');
Insert into ACORN0301.ADMINLOG (LOG_NUM,MEMBER_NUM,LOG_TIME,LOG_TABLE,LOG_ACT,LOG_MEMO,LOG_ATTR) values (6,18,to_date('19/07/30 03:00:00','RR/MM/DD HH24:MI:SS'),'menu','update',' 카테고리랑 메뉴설명 수정했습니다.','menu_type_num,menu_desc');
Insert into ACORN0301.ADMINLOG (LOG_NUM,MEMBER_NUM,LOG_TIME,LOG_TABLE,LOG_ACT,LOG_MEMO,LOG_ATTR) values (17,21,to_date('19/07/31 16:21:00','RR/MM/DD HH24:MI:SS'),'order','update',' ','qty0');
Insert into ACORN0301.ADMINLOG (LOG_NUM,MEMBER_NUM,LOG_TIME,LOG_TABLE,LOG_ACT,LOG_MEMO,LOG_ATTR) values (18,21,to_date('19/07/31 16:21:07','RR/MM/DD HH24:MI:SS'),'order','update',' ','order_status');
Insert into ACORN0301.ADMINLOG (LOG_NUM,MEMBER_NUM,LOG_TIME,LOG_TABLE,LOG_ACT,LOG_MEMO,LOG_ATTR) values (19,21,to_date('19/07/31 16:21:18','RR/MM/DD HH24:MI:SS'),'order','update',' ','order_status');
Insert into ACORN0301.ADMINLOG (LOG_NUM,MEMBER_NUM,LOG_TIME,LOG_TABLE,LOG_ACT,LOG_MEMO,LOG_ATTR) values (20,18,to_date('19/08/01 12:23:26','RR/MM/DD HH24:MI:SS'),'order','update',' ','order_status');
Insert into ACORN0301.ADMINLOG (LOG_NUM,MEMBER_NUM,LOG_TIME,LOG_TABLE,LOG_ACT,LOG_MEMO,LOG_ATTR) values (21,18,to_date('19/08/01 17:02:55','RR/MM/DD HH24:MI:SS'),'book','update',' ','book_status');
Insert into ACORN0301.ADMINLOG (LOG_NUM,MEMBER_NUM,LOG_TIME,LOG_TABLE,LOG_ACT,LOG_MEMO,LOG_ATTR) values (22,18,to_date('19/08/01 17:03:17','RR/MM/DD HH24:MI:SS'),'book','update',' ','head_count,check_out');
Insert into ACORN0301.ADMINLOG (LOG_NUM,MEMBER_NUM,LOG_TIME,LOG_TABLE,LOG_ACT,LOG_MEMO,LOG_ATTR) values (23,18,to_date('19/08/01 17:03:29','RR/MM/DD HH24:MI:SS'),'order','update',' ','order_status');
Insert into ACORN0301.ADMINLOG (LOG_NUM,MEMBER_NUM,LOG_TIME,LOG_TABLE,LOG_ACT,LOG_MEMO,LOG_ATTR) values (24,18,to_date('19/08/01 17:03:51','RR/MM/DD HH24:MI:SS'),'order','update',' ','qty0');
Insert into ACORN0301.ADMINLOG (LOG_NUM,MEMBER_NUM,LOG_TIME,LOG_TABLE,LOG_ACT,LOG_MEMO,LOG_ATTR) values (25,18,to_date('19/08/01 17:05:06','RR/MM/DD HH24:MI:SS'),'menu','insert',' ','all');
Insert into ACORN0301.ADMINLOG (LOG_NUM,MEMBER_NUM,LOG_TIME,LOG_TABLE,LOG_ACT,LOG_MEMO,LOG_ATTR) values (7,22,to_date('19/07/30 03:00:00','RR/MM/DD HH24:MI:SS'),'menu','delete',' ','all');
Insert into ACORN0301.ADMINLOG (LOG_NUM,MEMBER_NUM,LOG_TIME,LOG_TABLE,LOG_ACT,LOG_MEMO,LOG_ATTR) values (9,22,to_date('19/07/30 03:00:00','RR/MM/DD HH24:MI:SS'),'book','update',' ','head_count');
Insert into ACORN0301.ADMINLOG (LOG_NUM,MEMBER_NUM,LOG_TIME,LOG_TABLE,LOG_ACT,LOG_MEMO,LOG_ATTR) values (10,21,to_date('19/07/30 03:00:00','RR/MM/DD HH24:MI:SS'),'book','update',' ','check_out,book_memo,add_bed,breakfast_count');
Insert into ACORN0301.ADMINLOG (LOG_NUM,MEMBER_NUM,LOG_TIME,LOG_TABLE,LOG_ACT,LOG_MEMO,LOG_ATTR) values (11,21,to_date('19/07/30 03:00:00','RR/MM/DD HH24:MI:SS'),'order','update',' ','memo,qty0');
Insert into ACORN0301.ADMINLOG (LOG_NUM,MEMBER_NUM,LOG_TIME,LOG_TABLE,LOG_ACT,LOG_MEMO,LOG_ATTR) values (12,19,to_date('19/07/30 03:00:00','RR/MM/DD HH24:MI:SS'),'order','update',' ','order_status');
Insert into ACORN0301.ADMINLOG (LOG_NUM,MEMBER_NUM,LOG_TIME,LOG_TABLE,LOG_ACT,LOG_MEMO,LOG_ATTR) values (13,18,to_date('19/07/30 15:09:49','RR/MM/DD HH24:MI:SS'),'menu','update',' ','menu_price');
Insert into ACORN0301.ADMINLOG (LOG_NUM,MEMBER_NUM,LOG_TIME,LOG_TABLE,LOG_ACT,LOG_MEMO,LOG_ATTR) values (14,18,to_date('19/07/30 16:11:40','RR/MM/DD HH24:MI:SS'),'menu','update',' ','menu_price');
Insert into ACORN0301.ADMINLOG (LOG_NUM,MEMBER_NUM,LOG_TIME,LOG_TABLE,LOG_ACT,LOG_MEMO,LOG_ATTR) values (15,22,to_date('19/07/30 16:45:19','RR/MM/DD HH24:MI:SS'),'book','update',' ','book_status');
--------------------------------------------------------
--  DDL for Index SYS_C005381
--------------------------------------------------------

  CREATE UNIQUE INDEX "ACORN0301"."SYS_C005381" ON "ACORN0301"."ADMINLOG" ("LOG_NUM") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  Constraints for Table ADMINLOG
--------------------------------------------------------

  ALTER TABLE "ACORN0301"."ADMINLOG" ADD PRIMARY KEY ("LOG_NUM")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table ADMINLOG
--------------------------------------------------------

  ALTER TABLE "ACORN0301"."ADMINLOG" ADD FOREIGN KEY ("MEMBER_NUM")
	  REFERENCES "ACORN0301"."MEMBER" ("MEMBER_NUM") ENABLE;
